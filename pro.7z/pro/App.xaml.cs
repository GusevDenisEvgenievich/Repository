﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace pro
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

    public static class LogoutUtility
    {
        public static void ExecuteLogout(Window currentWindow)
        {
            MessageBoxResult result = MessageBox.Show(
                "Вы уверены, что хотите выйти?",
                "Подтверждение выхода",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                MainWindow mainWindow = new MainWindow();
                mainWindow.Show();
                currentWindow.Close();
            }
        }
    }

    public static class ButtonHelper
    {
        private static Button _activeButton;

        public static void SetActiveButton(Button button)
        {
            if (_activeButton != null)
            {
                _activeButton.Background = Brushes.DarkGray; // Сброс цвета активной кнопки
                _activeButton.Foreground = Brushes.White; // Установка исходного цвета текста
            }

            _activeButton = button; // Установка новой активной кнопки
            _activeButton.Background = Brushes.Gray; // Выделение новой активной кнопки
            _activeButton.Foreground = Brushes.Black; // Установка нового цвета текста
        }
    }

    public static class NavigationService
    {
        public static void NavigateTo<T>(Window currentWindow) where T : Window, new()
        {
            // Создаём новое окно
            T newWindow = new T();
            // Закрываем текущее окно
            currentWindow.Close();
            // Открываем новое окно
            newWindow.Show();
        }

        public static void NavigateToPage(Button clickedButton, Window currentWindow)
        {
            ButtonHelper.SetActiveButton(clickedButton);

            // Определите, какое окно нужно открыть в зависимости от нажатой кнопки
            if (clickedButton.Name == "ProductsButton")
            {
                NavigationService.NavigateTo<Products>(currentWindow);
            }
            else if (clickedButton.Name == "ArrivalButton")
            {
                NavigationService.NavigateTo<Entrance>(currentWindow);
            }
            else if (clickedButton.Name == "SalesButton")
            {
                NavigationService.NavigateTo<Realization>(currentWindow);
            }
            else if (clickedButton.Name == "ReportsButton")
            {
                NavigationService.NavigateTo<Reports>(currentWindow);
            }
            else if (clickedButton.Name == "DirectoriesButton")
            {
                NavigationService.NavigateTo<Directories>(currentWindow);
            }
            else if (clickedButton.Name == "EmployeesButton")
            {
                NavigationService.NavigateTo<Employees>(currentWindow);
            }
        }
    }
}
