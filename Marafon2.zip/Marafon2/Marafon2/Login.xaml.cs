﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Marafon2
{
    
    public partial class Login : Window
    {
        private CountdownTimer countdownTimer;

        public Login()
        {
            InitializeComponent();
            StartCountdown();
        }

        private void StartCountdown()
        {
            DateTime targetDate = new DateTime(2024, 12, 1);
            countdownTimer = new CountdownTimer(targetDate);
            countdownTimer.Tick += OnTimerTick;
        }

        private void OnTimerTick(string timeText)
        {
            CountdownTextBlock.Text = timeText;
        }

        private void ButtonNazad_Click(object sender, RoutedEventArgs e)
        {
            Window1 RegisterAsRunner = new Window1();
            RegisterAsRunner.Show();
            this.Close();

        }

        private void ButtonCancel_Click(object sender, object e)
        {
            MainWindow MainWindow = new MainWindow();
            MainWindow.Show();
            this.Close();
        }

        private void ButtonLogin_Click(object sender, RoutedEventArgs e)
        {
            String emailUser = EmailTextBox.Text;
            String passwordUser = PasswordBox.Password;

            BD db = new BD();
            DataTable table = new DataTable();
            MySqlDataAdapter adapter = new MySqlDataAdapter();

            MySqlCommand command = new MySqlCommand("SELECT * FROM `users` WHERE `email` = @eU AND `password` = @pU", db.GetConnection());
            command.Parameters.Add("@eU", MySqlDbType.VarChar).Value = emailUser;
            command.Parameters.Add("@pU", MySqlDbType.VarChar).Value = passwordUser;

            adapter.SelectCommand = command;
            adapter.Fill(table);

            if (table.Rows.Count > 0)
            {
                string userType = table.Rows[0]["RoleID"].ToString();

                if (userType == "3") // Замените "type1" на ваше условие
                {
                    MenuBeguna MenuBeguna = new MenuBeguna();
                    MenuBeguna.Show();
                }
                else if (userType == "1") // Замените "type2" на ваше условие
                {
                    MenuAdministratora MenuAdministratora = new MenuAdministratora();
                    MenuAdministratora.Show();
                }
                else if (userType == "2") // Замените "type3" на ваше условие
                {
                    MenuKoordinatora MenuKoordinatora = new MenuKoordinatora();
                    MenuKoordinatora.Show();
                }

                this.Close();
            }
            else
                MessageBox.Show("Введен неверный логин или пароль!");
        }
    }
}
