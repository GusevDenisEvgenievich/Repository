﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;

namespace Marafon2
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

    public class CountdownTimer
    {
        private DispatcherTimer timer;
        private DateTime targetDate;
        public event Action<string> Tick;

        public CountdownTimer(DateTime targetDate)
        {
            this.targetDate = targetDate;
            Start();
        }

        private void Start()
        {
            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick += Timer_Tick;
            timer.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            TimeSpan timeRemaining = targetDate - DateTime.Now;

            if (timeRemaining.TotalSeconds <= 0)
            {
                Tick?.Invoke("Марафон начался!");
                timer.Stop();
                return;
            }

            string timeText = $"{timeRemaining.Days} дней {timeRemaining.Hours} часов и {timeRemaining.Minutes} минут до старта марафона!";
            Tick?.Invoke(timeText);
        }
    }
}
