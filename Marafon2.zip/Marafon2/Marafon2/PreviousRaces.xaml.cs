﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Marafon2
{
    /// <summary>
    /// Логика взаимодействия для PreviousRaces.xaml
    /// </summary>
    public partial class PreviousRaces : Window
    {
        public ObservableCollection<RaceResult> RaceResults { get; set; }

        public PreviousRaces()
        {
            InitializeComponent();

            // Инициализация коллекции результатов
            RaceResults = new ObservableCollection<RaceResult>
        {
            new RaceResult { Place = 1, Time = "2:30:15", RunnerName = "Иван Иванов", Country = "Россия" },
            new RaceResult { Place = 2, Time = "2:35:10", RunnerName = "Петр Петров", Country = "Россия" },
            new RaceResult { Place = 3, Time = "2:40:05", RunnerName = "Джон Смит", Country = "США" },
            // Добавить больше результатов по мере необходимости
        };

            // Установка источника данных для DataGrid
            ResultsDataGrid.ItemsSource = RaceResults;
        }

        public class RaceResult
        {
            public int Place { get; set; }
            public string Time { get; set; }
            public string RunnerName { get; set; }
            public string Country { get; set; }
        }

        private void ButtonNazad_Click(object sender, RoutedEventArgs e)
        {
            FindInformation FindInformation = new FindInformation();
            FindInformation.Show();
            this.Close();
        }
    }

}
