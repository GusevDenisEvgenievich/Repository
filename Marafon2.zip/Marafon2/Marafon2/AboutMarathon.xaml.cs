﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Marafon2
{
    /// <summary>
    /// Логика взаимодействия для AboutMarathon.xaml
    /// </summary>
    public partial class AboutMarathon : Window
    {
        public AboutMarathon()
        {
            InitializeComponent();
        }

        private void Image_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ButtonState == MouseButtonState.Pressed)
            {
                // Открываем новое окно с изображением
                var ImageWindow = new ImageWindow("C:\\Users\\student\\Downloads\\Marathon2\\Marafon2\\Marafon2\\Image\\marathon-skills-2016-marathon-map.jpg");
                ImageWindow.Show();
            }
        }

        private void ButtonNazad_Click(object sender, RoutedEventArgs e)
        {
            FindInformation FindInformation = new FindInformation();
            FindInformation.Show();
            this.Close();
        }
    }
}
