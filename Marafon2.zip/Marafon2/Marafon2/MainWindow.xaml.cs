﻿using System;
using System.Windows;

namespace Marafon2
{
    public partial class MainWindow : Window
    {
        private CountdownTimer countdownTimer;

        public MainWindow()
        {
            InitializeComponent();
            StartCountdown();
        }

        private void StartCountdown()
        {
            DateTime targetDate = new DateTime(2024, 12, 1);
            countdownTimer = new CountdownTimer(targetDate);
            countdownTimer.Tick += OnTimerTick;
        }

        private void OnTimerTick(string timeText)
        {
            CountdownTextBlock.Text = timeText;
        }

        private void Button1_Click(object sender, RoutedEventArgs e)
        {
            Window1 RegisterAsRunner = new Window1();
            RegisterAsRunner.Show();
            this.Close();
        }

        private void ButtonLogin_Click(object sender, RoutedEventArgs e)
        {
            Login Login = new Login();
            Login.Show();
            this.Close();
        }

        private void Button3_Click(object sender, RoutedEventArgs e)
        {
            FindInformation FindInformation = new FindInformation();
            FindInformation.Show();
            this.Close();
        }
    }
}
