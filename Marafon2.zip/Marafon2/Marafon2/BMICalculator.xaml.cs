﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Marafon2
{
    public partial class BMICalculator : Window
    {
        private TranslateTransform _bmiPointerTransform;

        public BMICalculator()
        {
            InitializeComponent();
            // Создание и установка трансформации
            _bmiPointerTransform = new TranslateTransform();
            BmiPointer.RenderTransform = _bmiPointerTransform; // Устанавливаем трансформацию для указателя
        }

        private void Border_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (sender is Border selectedBorder)
            {
                // Сброс параметров границы и непрозрачности для обеих иконок
                MaleBorder.BorderThickness = new Thickness(0); // Сбрасываем границу для мужской иконки
                FemaleBorder.BorderThickness = new Thickness(0); // Сбрасываем границу для женской иконки
                MaleBorder.Opacity = 1; // Возвращаем прозрачность для мужской иконки
                FemaleBorder.Opacity = 1; // Возвращаем прозрачность для женской иконки

                // Устанавливаем границу для выбранной
                selectedBorder.BorderThickness = new Thickness(2);
                selectedBorder.BorderBrush = Brushes.Black;

                // Уменьшаем непрозрачность для невыбранной
                if (selectedBorder == MaleBorder)
                {
                    FemaleBorder.Opacity = 0.7;
                }
                else
                {
                    MaleBorder.Opacity = 0.7;
                }
            }
        }

        private void Image_MouseEnter(object sender, MouseEventArgs e)
        {
            if (sender is Image image)
            {
                image.Opacity = 0.7; // уменьшить непрозрачность для выделения
            }
        }

        private void Image_MouseLeave(object sender, MouseEventArgs e)
        {
            if (sender is Image image)
            {
                image.Opacity = 1; // вернуть непрозрачность обратно
            }
        }

        private void ButtonNazad_Click(object sender, RoutedEventArgs e)
        {
            FindInformation findInformation = new FindInformation();
            findInformation.Show();
            this.Close();
        }

        private void CalculateBMI_Click(object sender, RoutedEventArgs e)
        {
            if (double.TryParse(HeightTextBox.Text, out double height) && double.TryParse(WeightTextBox.Text, out double weight))
            {
                height /= 100; // Конвертация в метры
                double bmi = weight / (height * height); // Расчет BMI
                BmiAboveArrowTextBlock.Text = $"BMI: {bmi:F2}";

                // Обновление изображения в зависимости от значения BMI
                if (bmi < 18.5)
                {
                    MovePointer(0);
                    DisplayedResult.Source = new BitmapImage(new Uri("C:\\Users\\student\\Desktop\\Marafon2\\Marafon2\\Image\\bmi-underweight-icon.png"));
                }
                else if (bmi < 24.9)
                {
                    MovePointer(1);
                    DisplayedResult.Source = new BitmapImage(new Uri("C:\\Users\\student\\Desktop\\Marafon2\\Marafon2\\Image\\bmi-healthy-icon.png"));
                }
                else if (bmi < 29.9)
                {
                    MovePointer(2);
                    DisplayedResult.Source = new BitmapImage(new Uri("C:\\Users\\student\\Desktop\\Marafon2\\Marafon2\\Image\\bmi-overweight-icon.png"));
                }
                else
                {
                    MovePointer(3);
                    DisplayedResult.Source = new BitmapImage(new Uri("C:\\Users\\student\\Desktop\\Marafon2\\Marafon2\\Image\\bmi-obese-icon.png"));
                }
            }
            else
            {
                MessageBox.Show("Пожалуйста, введите корректные значения роста и веса.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }


        private void MovePointer(int segment)
        {
            double segmentWidth = Straight.ActualWidth;
            int numberOfSegments = 4;
            if (segmentWidth > 0 && numberOfSegments > 0)
            {
                double offset = (segmentWidth / numberOfSegments) * segment;
                DoubleAnimation animation = new DoubleAnimation
                {
                    To = offset,
                    Duration = TimeSpan.FromSeconds(0.5), // Длительность анимации
                    EasingFunction = new QuadraticEase { EasingMode = EasingMode.EaseInOut } // Плавность анимации
                };
                _bmiPointerTransform.BeginAnimation(TranslateTransform.XProperty, animation);
            }
            else
            {
                MessageBox.Show("Ошибка: ширина для анимации недоступна.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Border_MouseLeave(object sender, MouseEventArgs e)
        {
            if (sender is Border border)
            {
                // Возвращаем непрозрачность обратно для не выбранной иконки
                if (border != MaleBorder && border != FemaleBorder)
                {
                    border.Opacity = 1;
                }
                else
                {
                    // Если это выбранная иконка, сохраняем низкую непрозрачность
                    if (border.BorderBrush == Brushes.Black)
                    {
                        border.Opacity = 1; // Восстанавливаем непрозрачность для выбранной
                    }
                }
            }
        }
    }
}
