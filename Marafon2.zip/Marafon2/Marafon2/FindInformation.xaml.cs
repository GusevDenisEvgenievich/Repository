﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Marafon2
{
    /// <summary>
    /// Логика взаимодействия для FindInformation.xaml
    /// </summary>
    public partial class FindInformation : Window
    {
        private CountdownTimer countdownTimer;

        public FindInformation()
        {
            InitializeComponent();
            StartCountdown();
        }

        private void StartCountdown()
        {
            DateTime targetDate = new DateTime(2024, 12, 1);
            countdownTimer = new CountdownTimer(targetDate);
            countdownTimer.Tick += OnTimerTick;
        }

        private void OnTimerTick(string timeText)
        {
            CountdownTextBlock.Text = timeText;
        }

        private void ButtonNazad_Click(object sender, RoutedEventArgs e)
        {
            MainWindow MainWindow = new MainWindow();
            MainWindow.Show();
            this.Close();
        }

        private void Button1_Click(object sender, RoutedEventArgs e)
        {
            AboutMarathon AboutMarathon = new AboutMarathon();
            AboutMarathon.Show();
            this.Close();
        }

        private void Button4_Click(object sender, RoutedEventArgs e)
        {
            PreviousRaces PreviousRaces = new PreviousRaces();
            PreviousRaces.Show();
            this.Close();
        }
    }
}
