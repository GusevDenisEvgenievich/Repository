﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace pro
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

    public static class LogoutUtility
    {
        public static void ExecuteLogout(Window currentWindow)
        {
            MessageBoxResult result = MessageBox.Show(
                "Вы уверены, что хотите выйти?",
                "Подтверждение выхода",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                MainWindow mainWindow = new MainWindow();
                mainWindow.Show();
                currentWindow.Close();
            }
        }
    }

    public static class ButtonHelper
    {
        private static Border _activeBorder;

        public static void SetActiveBorder(Border border)
        {
            if (_activeBorder != null)
            {
                _activeBorder.Background = Brushes.Transparent; // Сброс цвета активной границы
            }

            _activeBorder = border; // Установка новой активной границы
            _activeBorder.Background = Brushes.Orange; // Выделение новой активной границы
        }

        public static void SetActiveButton(Button button)
        {
            // Здесь можно добавить логику для изменения состояния кнопки, 
            // например, изменение цвета или стиля.
            button.Background = Brushes.Orange; // Выделение активной кнопки
        }
    }

    public static class NavigationService
    {
        public static void NavigateTo<T>(Window currentWindow) where T : Window, new()
        {
            // Создаём новое окно
            T newWindow = new T();
            // Закрываем текущее окно
            currentWindow.Close();
            // Открываем новое окно
            newWindow.Show();
        }
    }
}
