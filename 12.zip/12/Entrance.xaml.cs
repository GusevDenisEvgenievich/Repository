﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Collections.ObjectModel;

namespace pro
{
    public partial class Entrance : UserControl
    {
        public class Product
        {
            public string ProductNumber { get; set; }
            public string Barcode { get; set; }
            public string ProductCode { get; set; }
            public string NameAndBrand { get; set; }
            public string UnitMeasure { get; set; }
            public int Quantity { get; set; }
            public decimal PurchasePriceWithoutVAT { get; set; }
            public decimal VATRate { get; set; }
            public decimal VATAmount
            {
                get
                {
                    return PurchasePriceWithoutVAT * (VATRate / 100);
                }
            }
            public decimal TotalCostWithVAT
            {
                get
                {
                    return PurchasePriceWithoutVAT + VATAmount;
                }
            }
        }

        public ObservableCollection<Product> Products { get; set; } // Объявление Products

        public Entrance()
        {
            InitializeComponent();
            Products = new ObservableCollection<Product>
            {
                new Product() // Добавляем одну строку по умолчанию
                {
                    ProductNumber = "1",
                    Barcode = "1234567890123",
                    ProductCode = "001",
                    NameAndBrand = "Пример товара",
                    UnitMeasure = "шт",
                    Quantity = 1,
                    PurchasePriceWithoutVAT = 100,
                    VATRate = 20
                }
            };

            DataGridProducts.ItemsSource = Products;
            UpdateTotals();
        }

        private void AddRow_Click(object sender, RoutedEventArgs e)
        {
            Products.Add(new Product()); // Добавляем пустую строку
            UpdateTotals();
        }

        private void UpdateTotals()
        {
            decimal totalWithoutVAT = 0;
            decimal totalVAT = 0;
            decimal totalWithVAT = 0;

            var vatGroups = Products.GroupBy(p => p.VATRate).ToDictionary(g => g.Key, g => g.Sum(p => p.VATAmount));

            foreach (var product in Products)
            {
                totalWithoutVAT += product.PurchasePriceWithoutVAT;
                totalWithVAT += product.TotalCostWithVAT;
            }

            string vatSummary = string.Join(", ", vatGroups.Select(g => $"{g.Key}%: {g.Value}"));

            TotalPurchasePriceWithoutVAT.Text = totalWithoutVAT.ToString();
            TotalVAT.Text = "Сумма НДС с группировкой по ставке НДС (%): " + vatSummary;
            TotalCostWithVAT.Text = totalWithVAT.ToString();
        }

    }
}
