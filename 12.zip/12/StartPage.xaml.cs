﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace pro
{
    public partial class StartPage : Window
    {
        public StartPage()
        {
            InitializeComponent();
        }

        private void NavigationTextBlock_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (sender is Border border)
            {
                string tag = border.Tag.ToString();
                ButtonHelper.SetActiveBorder(border);
                LoadPage(tag);
            }
        }

        private void LoadPage(string page)
        {
            UserControl userControl = CreatePage(page);

            if (userControl != null)
            {
                MainContentArea.Content = userControl; // Заменяем содержимое основной области
            }
            else
            {
                // Обработка ошибки или установка страницы по умолчанию
            }
        }

        private UserControl CreatePage(string page)
        {
            switch (page)
            {
                case "Товары":
                    return new Products();
                case "Поступление":
                    return new Entrance();
                case "Реализация":
                    return new Realization();
                default:
                    return null; // или можно вернуть страницу по умолчанию
            }
        }

        private void Logout_Click(object sender, RoutedEventArgs e)
        {
            LogoutUtility.ExecuteLogout(this);
        }
    }
}
